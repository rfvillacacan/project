<?php
require_once 'includes/config.php';

echo '<div class="table-responsive">';
echo '<table class="table table-bordered table-striped table-dark datatable-service-progress">';
echo '<thead>
        <tr>
            <th>No.</th>
            <th>Service</th>
            <th>Due Date</th>
            <th>Progress</th>
            <th>Comments</th>
            <th>Action</th>
        </tr>
      </thead>
      <tbody></tbody>';
echo '</table></div>';
?> 
