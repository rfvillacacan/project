<?php
require_once 'includes/config.php';

echo '<div class="table-responsive">';
echo '<table class="table table-bordered table-striped table-dark datatable-is-projects">';
echo '<thead>
        <tr>
            <th>No.</th>
            <th>Project</th>
            <th>Due Date</th>
            <th>Progress</th>
            <th>Assigned Team</th>
            <th>Comments</th>
            <th>Action</th>
        </tr>
      </thead>
      <tbody></tbody>';
echo '</table></div>';
?> 
